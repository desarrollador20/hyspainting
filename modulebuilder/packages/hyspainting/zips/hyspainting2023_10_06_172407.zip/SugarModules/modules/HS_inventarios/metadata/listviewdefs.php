<?php
$module_name = 'HS_inventarios';
$listViewDefs [$module_name] = 
array (
  'NUM_SERIE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_NUM_SERIE',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'MARCA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MARCA',
    'width' => '10%',
    'default' => true,
  ),
  'MODELO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MODELO',
    'width' => '10%',
    'default' => true,
  ),
  'UBICACION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_UBICACION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'PRESTADO_A' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PRESTADO_A',
    'id' => 'USER_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'PRESTADO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRESTADO ',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
;
?>
