<?php
// created: 2024-01-07 20:53:40
$dictionary["HS_Facturador_proyectos"]["fields"]["hs_facturador_proyectos_notes"] = array (
  'name' => 'hs_facturador_proyectos_notes',
  'type' => 'link',
  'relationship' => 'hs_facturador_proyectos_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_HS_FACTURADOR_PROYECTOS_NOTES_FROM_NOTES_TITLE',
);
